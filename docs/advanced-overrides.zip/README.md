# Advanced Overrides Panel

독립 패널로 Tailwind 추천, 정적 분석(금지 속성 경고), 프리셋 저장 기능을 제공합니다.
