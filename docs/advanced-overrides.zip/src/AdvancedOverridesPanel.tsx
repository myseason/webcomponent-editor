import React from 'react';
export default function AdvancedOverridesPanel(){return <div>Advanced Overrides</div>}
