export type Preset = {id: string; name: string; data: any};
