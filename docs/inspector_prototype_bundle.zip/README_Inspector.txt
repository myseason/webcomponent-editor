Inspector Prototype 열기 가이드
==============================

1) 아래 파일을 다운로드 받아 더블클릭하여 여세요.
   - inspector_prototype.html  (메인 프로토타입)
   - inspector_prototype_v2.html (백업)
   - inspector_min.html (최소 테스트 페이지 - 이것부터 열리는지 확인)

2) 크롬/엣지에서 보안 플러그인/확장프로그램이 'sandbox:' 링크를 막는 경우,
   페이지의 전체 코드를 복사해 'inspector_prototype.html'로 저장 후 여세요.

3) 여전히 안 열리면:
   - 파일을 우클릭 > 다른 이름으로 저장
   - 또는 브라우저 주소창에 file:/// 경로로 직접 열기